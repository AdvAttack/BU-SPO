class Config(object):
    num_classes = {'imdb': 2, 'yahoo': 10, 'yahoo_csv': 10, 'agnews': 4}
    word_max_len = {'imdb': 400, 'yahoo': 1000, 'yahoo_csv': 1000, 'agnews': 150}
    char_max_len = {'agnews': 1014, 'yahoo_csv': 1000}
    num_words = {'imdb': 5000, 'yahoo': 20000, 'yahoo_csv': 20000, 'agnews': 5000}

    wordCNN_batch_size = {'imdb': 32, 'yahoo': 32, 'yahoo_csv': 32, 'agnews': 32}
    wordCNN_epochs = {'imdb': 2, 'yahoo': 6, 'yahoo_csv': 6, 'agnews': 2}

    bdLSTM_batch_size = {'imdb': 32, 'yahoo': 32, 'yahoo_csv': 64, 'agnews': 64}
    bdLSTM_epochs = {'imdb': 6, 'yahoo': 16, 'yahoo_csv': 2, 'agnews': 2}

    charCNN_batch_size = {'agnews': 128, 'yahoo_csv': 64}
    charCNN_epochs = {'agnews': 4, 'yahoo_csv': 10}

    LSTM_batch_size = {'imdb': 32, 'yahoo': 64, 'yahoo_csv': 64, 'agnews': 64}  # 'yahoo_csv': 128
    LSTM_epochs = {'imdb': 50, 'yahoo': 30, 'yahoo_csv': 2, 'agnews': 30}  # 'yahoo_csv': 30

    loss = {'imdb': 'binary_crossentropy', 'yahoo': 'categorical_crossentropy', 'yahoo_csv': 'categorical_crossentropy', 'agnews': 'categorical_crossentropy'}
    activation = {'imdb': 'sigmoid', 'yahoo': 'softmax', 'yahoo_csv': 'softmax', 'agnews': 'softmax'}

    wordCNN_embedding_dims = {'imdb': 50, 'yahoo': 50, 'yahoo_csv': 50, 'agnews': 50}
    bdLSTM_embedding_dims = {'imdb': 128, 'yahoo': 128, 'yahoo_csv': 128, 'agnews': 128}
    LSTM_embedding_dims = {'imdb': 100, 'yahoo': 100, 'yahoo_csv': 100, 'agnews': 100}


config = Config()
